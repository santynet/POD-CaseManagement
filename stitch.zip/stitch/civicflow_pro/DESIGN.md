# Design System Strategy: Municipal Case Management

## 1. Overview & Creative North Star
Moving away from the legacy "green-on-black" mainframe aesthetic requires more than just a color swap; it requires a complete paradigm shift in cognitive load management. Our Creative North Star is **"The Civic Ledger."** 

This system represents a sophisticated, editorial approach to civic administration. Instead of the chaotic, dense information clusters found in the original terminal, we use **intentional asymmetry** and **tonal depth** to guide the eye. We break the "template" look by using exaggerated whitespace and high-contrast typography scales that prioritize "the story of the case" over a wall of raw data. The result is a high-end digital environment that feels authoritative, transparent, and calm.

## 2. Colors & Surface Philosophy
The palette utilizes deep municipal blues (`primary: #2d6197`) and sophisticated slate grays (`secondary: #526074`) to establish trust and professional clarity.

*   **The "No-Line" Rule:** To achieve a premium, custom feel, 1px solid borders are strictly prohibited for sectioning. Structural boundaries must be defined solely through background color shifts. For example, a court hearing details section (`surface-container-low: #eef4fa`) should sit directly on the main application background (`background: #f6fafe`) without a stroke.
*   **Surface Hierarchy & Nesting:** We treat the UI as a series of physical layers. Use the surface-container tiers (Lowest to Highest) to create "nested" depth. A case record might be hosted on `surface-container`, while secondary metadata widgets sit inside it on `surface-container-high`.
*   **The "Glass & Gradient" Rule:** For floating navigation or action panels, utilize Glassmorphism. Use semi-transparent variants of `surface` with a 12px-20px backdrop-blur. 
*   **Signature Textures:** Main Call-to-Actions (CTAs) for citation entry should use a subtle linear gradient from `primary` (#2d6197) to `primary_dim` (#1d548a) to provide a tactile, professional polish that flat color cannot replicate.

## 3. Typography: The Editorial Scale
We use **Inter** as our sole typeface, relying on a rigorous hierarchy to replace the monolithic density of the old system.

*   **Display & Headline (The Big Picture):** Use `display-sm` (2.25rem) for high-level dashboard summaries (e.g., "Total Outstanding Fines"). These should feel like news headlines—authoritative and immediate.
*   **Title (The Case Subject):** `title-lg` (1.375rem) is reserved for Case IDs and Primary Violator Names. This provides a clear anchor for each record.
*   **Body (The Facts):** `body-md` (0.875rem) is the workhorse for citation details. Use `on_surface_variant` (#52616a) for labels to create a soft contrast against the `on_surface` (#26343d) values.
*   **Labels (The Metadata):** Use `label-sm` (0.6875rem) in All-Caps with a 0.05em letter-spacing for category headers to mimic the precision of a high-end legal document.

## 4. Elevation & Depth
Depth is communicated through **Tonal Layering** rather than shadows.

*   **The Layering Principle:** Place a `surface-container-lowest` (#ffffff) card on a `surface-container-low` (#eef4fa) section to create a soft, natural lift. This creates "clean" depth that doesn't muddy the interface.
*   **Ambient Shadows:** For temporary modals or dropdowns, use extra-diffused shadows (Blur: 32px, Y: 12px) at 6% opacity. The shadow color should be a tinted version of `on_surface` to simulate natural light.
*   **The "Ghost Border" Fallback:** If a container requires a boundary (e.g., in high-density data tables), use a **Ghost Border**: the `outline_variant` token (#a4b4be) at 15% opacity.
*   **Glassmorphism:** Use semi-transparent surface colors for the specialized hearing calendar, allowing the underlying deep blues to bleed through, softening the transition between data views.

## 5. Components

### Citation Data Tables
*   **No Dividers:** Forbid the use of horizontal lines. Distinguish rows through `surface-container` background shifts on hover.
*   **Asymmetric Columns:** Use wider gutters for status columns to create visual breathing room.
*   **Status Indicators:** Use `error` (#9f403d) for violations, `primary` (#2d6197) for pending, and a custom success emerald for paid. These should be styled as minimal "Pills" with `surface-container-highest` backgrounds.

### Form Inputs (Citation Entry)
*   **The Signature Input:** Forgo the 4-sided box. Use a `surface-container-highest` background with a 2px `primary` bottom-border that activates on focus.
*   **Roundedness:** Apply `md` (0.375rem) to all input corners to soften the municipal "hardness."

### Court Hearing Calendar
*   **The Specialized View:** A hybrid list-calendar. Use a vertically stacked list where the date is an oversized `headline-sm` element to the left, and case details are nested to the right on a `surface-container-lowest` card.

### Buttons & Chips
*   **Primary Button:** Gradient fill (`primary` to `primary_dim`) with `lg` (0.5rem) roundedness.
*   **Action Chips:** Use `secondary_container` (#d5e3fc) for inactive filters and `primary` for active states. No borders.

## 6. Do's and Don'ts

### Do
*   **Do** use `surface-container-lowest` for the most important data (the "active" paper).
*   **Do** prioritize vertical whitespace over lines. If two pieces of data feel cluttered, increase the gap to `1.5rem` rather than adding a divider.
*   **Do** use `tertiary` (#ba1e21) sparingly for high-alert violations (e.g., "Impound Requested").

### Don't
*   **Don't** use pure black (#000000). Always use `on_surface` (#26343d) to maintain the sophisticated slate-blue tone.
*   **Don't** use 100% opaque borders. They create "visual noise" that recalls the rigid grid of the mainframe.
*   **Don't** crowd the "Citation Entry" forms. Use a single-column layout with generous `body-lg` labels to ensure accuracy for the clerk.